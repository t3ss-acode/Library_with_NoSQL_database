package model;

import com.mongodb.*;
import com.mongodb.MongoClient;
import com.mongodb.client.*;
import databaseUtils.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.objects.Author;
import model.objects.Book;
import org.bson.Document;

import java.util.ArrayList;
import java.util.Date;
import java.util.regex.Pattern;

public class AddBookAuthorModel implements DbAddBookInterface {
    private ArrayList<Author> authorsList = new ArrayList<>();
    private ObservableList<Author> existingAuthors = FXCollections.observableArrayList();
    private Book book;
    private MongoClient client;
    private MongoDatabase database;

    public AddBookAuthorModel() throws DbConnException{
        client = DbConnector.getConnection();
        database = client.getDatabase("db1");
    }

    /**
     * Takes the given parameters and makes a Book object
     */
    @Override
        public void addBook(Book book){
        this.book = book;
    }

    /**
     * Takes the given parameters and makes an Author object
     */
    public void addAuthor(Author author){
        authorsList.add(author);
        System.out.println(authorsList.toString());
    }

    /**
     * Add the arrayList of Authors to the Book object
     */
    public void addAuthors(){
        book.addAuthors(authorsList);
        System.out.println("Authors : " + authorsList.toString());
    }

    /**
     * Checks if the given title a valid title
     * @param title
     * @return boolean value for if the title uphold the requirements
     */

    /**
     * Adds the book into the database
     *
     * @throws DbInsertException
     */
    public void addToDB() throws DbInsertException, DbConnException {
        try(ClientSession clientSession = client.startSession()){
            clientSession.startTransaction();

        }
    }

    private void addBookToDB(){

    }

    private void addAuthorToDB(){

    }

    // Inte klar..
    public ObservableList<Author> searchAuthor(String searchWord) throws DbConnException{
        BasicDBObject whereQuery = new BasicDBObject();
        Document pop = new Document();

        MongoCollection<Document> collection = database.getCollection("authors");

        pop.append("$regex", ".*" + Pattern.quote(searchWord) + ".*");
        whereQuery.put("firstName", pop);
        try{
            //Cursor points to the first document that fulfills the query
            FindIterable<Document> cursor = collection.find(whereQuery);

            convertToAuthorObject(cursor);

        }catch(MongoException ex){
            throw new DbConnException("Database Connection Failed");
        }
        return existingAuthors;
    }

    private void convertToAuthorObject(FindIterable<Document> cursor) {
        existingAuthors.clear();

        String firstName = null;
        String lastName = null;
        Date dob = null;

        for(Document docs : cursor) {
            firstName = docs.getString("firstName");
            lastName = docs.getString("lastName");
            dob = docs.getDate("dob");

            Author author = new Author(firstName, lastName, dob);
            existingAuthors.add(author);
        }

    }
}