package model.objects;

import java.sql.Date;

public class User {
    private String userName;
    private String email;
    private String passWord;
    private Date dob;
    private Date accCreatedDate;

    public User() {

    }

}
