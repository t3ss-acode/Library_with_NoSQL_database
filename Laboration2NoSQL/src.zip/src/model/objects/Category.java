package model.objects;

/**
 * Enum that defines the categories a book can be in
 */
public enum Category {
    fantasy, crime, horror, comedy, scifi, romance
}
