package model;

import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoException;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import databaseUtils.DbConnException;
import databaseUtils.DbConnector;
import org.bson.Document;


public class LoginModel{
    private MongoDatabase mongoDatabase;
    public LoginModel(){
        try{
            connectToDb();
        }catch(DbConnException ex){
            ex.getMessage();
        }
    }
    /**
     * Connect to the database
     *
     * @throws DbConnException
     */
    private void connectToDb() throws DbConnException{
        MongoClient client = DbConnector.getConnection();
        mongoDatabase = client.getDatabase("db1");

        //mongoDatabase = DbConnector.getConnection();
    }

    /**
     * Checks if it's connected to the database
     *
     * @return boolean if it's connected
     */
    public boolean isDbConnected(){
        return this.mongoDatabase != null;
    }

    /**
     * Checks if the given username and password is in the database
     *
     * @param username
     * @param password
     * @return boolean if the parameters are in the database
     */
    public boolean tryLogin(String username, String password) throws MongoException {
        BasicDBObject loginFindQuery = new BasicDBObject();
        loginFindQuery.append("username", username);
        loginFindQuery.append("password", password);

        MongoCollection<Document> userCollection = mongoDatabase.getCollection("Users");
        int userCount = Math.toIntExact(userCollection.countDocuments(loginFindQuery));
        System.out.println(userCount);
        return userCount != 0;
    }
}
