package databaseUtils;

public class DbInsertException extends Exception {
    public DbInsertException(String message){
        super(message);
    }
}
